// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBqb7sTyPoN3WBRousaEW3LaLN7bdQJbaM",
  authDomain: "coffee-spark-ai-barista-dc3de.firebaseapp.com",
  projectId: "coffee-spark-ai-barista-dc3de",
  storageBucket: "coffee-spark-ai-barista-dc3de.firebasestorage.app",
  messagingSenderId: "1000677675660",
  appId: "1:1000677675660:web:c3cdf8fccb6a65df8f21a9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);